setwd("C:\\Users\\hrind\\OneDrive\\Desktop\\IT24104312")

#Exercise

#1
#distribution of X = Binomial(n=50,p=0.85)
pbinom(46, 50, 0.85, lower.tail = FALSE)

#2
#X = Number of customer calls received in one hour
#distribution of X = Poisson(lamda=12)
dpois(15, 12)
