setwd("C:\\Users\\hrind\\OneDrive\\Desktop\\IT24104312")
Delivery_Times<-read.table("Exercise - Lab 05.txt",header=TRUE)
hist(Delivery_Times$Delivery_Time_.minutes,
     main="Histogram of delivery times",
     xlab="Delivery times (minutes)",
     breaks=seq(20,70,length=10),
     right=FALSE,
     col="lightblue",
     border="black") 

hist_obj <- hist(Delivery_Times$Delivery_Time_.minutes.,
                 breaks = seq(20, 70, length = 10),
                 right = FALSE,
                 plot = FALSE)

cum_freq <- c(0, cumsum(hist_obj$counts))

plot(hist_obj$breaks, cum_freq,
     type = "l",  
     main = "Cumulative Frequency Polygon (Ogive) of Delivery Times",
     xlab = "Delivery Time (minutes) - Upper Class Limit",
     ylab = "Cumulative Frequency",
     col = "darkred",
     lwd = 2)

points(hist_obj$breaks, cum_freq, pch = 16, col = "darkred")